package forma;

// Classe Quadrado é uma subclasse de Retangulo, visto que esse quadrado é um tipo especial de retangulo.

public class Quadrado extends Retangulo {


	public Quadrado(double lado) {
		super(lado, lado);
	}
	
}
