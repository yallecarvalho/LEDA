package forma;

/*
 * Interface forma com o método área que será usado por todas as formas. 
 */

public interface Forma {
	
	public double area();

}
